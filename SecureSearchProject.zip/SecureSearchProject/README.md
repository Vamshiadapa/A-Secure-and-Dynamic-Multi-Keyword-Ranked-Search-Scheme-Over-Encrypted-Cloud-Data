# Secure Multi-Keyword Search over Encrypted Cloud Data

## Tools Used
- Java
- JavaFX
- SQLite
- Apache Lucene
- AES Encryption

## Structure
- `crypto/` - AES encryption utilities
- `db/` - SQLite file metadata manager
- `indexer/` - Lucene index management
- `gui/` - JavaFX user interface

## How to Run
See section 5 of the ChatGPT output for compile and run instructions.